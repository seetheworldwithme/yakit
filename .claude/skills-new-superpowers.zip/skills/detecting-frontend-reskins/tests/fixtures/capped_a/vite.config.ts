export default { root: 'src' }
